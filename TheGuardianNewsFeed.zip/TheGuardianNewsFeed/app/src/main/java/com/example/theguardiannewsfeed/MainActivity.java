package com.example.theguardiannewsfeed;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {
    private static final String NO_RESPONSE ="Server not Responding";
    private static final String NETWORK_CONNECT_ERROR = "Network Connection Error";
    static ArrayList<Feed_Item> feed_item = new ArrayList();
    String query_Item = "dabates";
    String url_String;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Builder method
        Uri.Builder builder = new Uri.Builder();
        builder.scheme("https")
                .authority("content.guardianapis.com")
                .appendPath("search")
                .appendQueryParameter("show-fields", "thumbnail")
                .appendQueryParameter("q", query_Item)
                .appendQueryParameter("api-key", "test");
        url_String = builder.build().toString();

        try {
            getNewsFeed();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void getNewsFeed() throws ExecutionException, InterruptedException {

        ConnectivityManager connMgr = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();

        //Check if the network is active
        if (networkInfo != null && networkInfo.isConnected()) {

            // The news feed is retrieved in an AsyncTask class. execute method takes in the stringUrl and starts data retrieval
            new GetFeedTask().execute(url_String);

        } else {
            Toast.makeText(MainActivity.this, NETWORK_CONNECT_ERROR, Toast.LENGTH_SHORT).show();

        }
        url_String = null;
        query_Item = null;
    }

    class GetFeedTask extends AsyncTask<String, Void, String> {

        protected String doInBackground(String... urls) {

            try {
                URL url = new URL(urls[0]);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                try {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    return stringBuilder.toString();
                } finally {
                    urlConnection.disconnect();
                }
            } catch (Exception e) {
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this, NO_RESPONSE, Toast.LENGTH_SHORT).show();
                    }
                });
                return "";
            }

        }

        //listing items on list view
        @Override
        protected void onPostExecute(String res) {

            try {
                JSONObject object = new JSONObject(res).getJSONObject("response");
                int numberOfItems = object.getInt("results");

                if (numberOfItems == 0) {
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                    Toast.makeText(MainActivity.this, "No Item matching your request", Toast.LENGTH_SHORT).show();
                        }
                    });
                }

                JSONArray items = object.getJSONArray("results");


                for (int i = 0; i < items.length(); i++) {
                    JSONObject item = items.getJSONObject(i);

                    String title = item.getString("webTitle");
                    String webLink = item.getString("webUrl");

                    if (item.has("fields") && item.getJSONObject("fields").has("thumbnail")) {
                        String thumbnailLink = item.getJSONObject("fields").getString("thumbnail");

                        feed_item.add(new Feed_Item(title, webLink, thumbnailLink));
                    } else
                        feed_item.add(new Feed_Item(title, webLink));
                }

                ListView listView = (ListView) findViewById(R.id.feed_list);


                GuardianAdapter adapter = new GuardianAdapter(MainActivity.this, feed_item);

                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {


                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(feed_item.get(position).getWebUrl()));
                        startActivity(intent);
                    }
                });
                listView.setAdapter(adapter);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }
    }
